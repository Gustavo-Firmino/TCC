<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css-pasta/estilos.css">
		<title>Lib-Lab</title>
	</head>
	<body>
		<header>
			<nav>
				<ul class="topnav">
					<li><a href="index.php"> HOME</a></li>
					<li><a class="active" href=""> Fale conosco!</a></li>
					<li class="right"><a href="log.php">Login</a></li>
					<li class="right"><a href="cad.php">Cadastro</a></li>
				</ul>
			</nav>
			<h1><i>Lib-Lab</i></h1>
		</header>
		<section>
			<h1>
				Fale conosco!
			</h1>
		</section>
		<footer>
			<p>Todos os direitos estão reservados à ToniniCorporation¶ </p>
		</footer>
	</body>
</html>