	function menu() {
		location.replace("menupri.php")
	}