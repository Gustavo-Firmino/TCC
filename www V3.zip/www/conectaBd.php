<?php
		//conectar BD
//dev
		$servidorCONN="127.0.0.1"; //proprio equipamento; porém caso utilize um servidor, basta mudar o IP
		$usuarioCONN="root";
		$senhaCONN="";
		$bdCONN="gus"; //muda o servidor de BD
		$conn = mysqli_connect($servidorCONN, $usuarioCONN, $senhaCONN,$bdCONN);//passagem de parametros, para realizar 
//server
/*
		$servidorCONN="172.16.0.8";		  
		$usuarioCONN="20017";
		$senhaCONN="!zzeune";
		$bdCONN="20017";
		$conn=mysqli_connect($servidorCONN,$usuarioCONN,$senhaCONN,$bdCONN);
		if(!$conn){
    			die("Não foi possível fazer a conexão com o BD");
		}
*/
?>