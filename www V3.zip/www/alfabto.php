<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>ALFABETO</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		 <h1>ALFABETO</h1>
            <ul class="topnav">
				<li><a href="index.php"> HOME</a></li>
                <li><a href="menupri.php">MENU</a></li>
                <li><a class="active" href="alfabto.php"> ALFABETO</a></li>
                <li class="right"><a href="sair.php" id="sair">SAIR</a></li>
		    </ul>
		    <br>
			<div class="galeria">
			    <img src="images/letraa.png" alt="Letra A" width="600" height="400">
			  <div class="desc">Letra A</div>
			</div>
https://www.w3schools.com/howto/howto_css_flip_card.asp
			<div class="galeria">
			    <img src="images/letrab.png" alt="Letra B" width="600" height="400">
			  <div class="desc">Letra B</div>
			</div>

			<div class="galeria">
			    <img src="images/letrac.png" alt="Letra C" width="600" height="400">
			  <div class="desc">Letra C</div>
			</div>
	</body>
</html>