<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style/style.css">
	<title>Inicial</title>
</head>
<body>
	<h1>Listagem</h1>
	<a href="lista.php">listar registros</a> <br><br>
	<a href="pesquisar.php">pesquisar registros</a> <br>
</body>
</html>