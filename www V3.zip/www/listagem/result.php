<?php
	require("conectaBd.php");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style/style.css">
	<title>Resultado pesquisa</title>
</head>
<body>
	<?php
		$pesquisa=$_POST['pesquisa'];
		$sql = "select cpf,nome,telefone from cliente where nome LIKE '???'";
		$stmt = mysqli_prepare($conn, $sql);
		if(!$stmt){
			die("Não foi possível preparar a consulta!");
		}
		$bind = mysqli_bind_param($stmt, "sss",$pesquisa);
		if(!$bind){
			die("Impossível vincular dados a consulta");
		}
		if(mysqli_num_rows($ds)==0){
			echo("Não há dados");
		}else{
			echo("<table>");
				echo("<tr>");
					echo("<th>CPF</th>");
					echo("<th>NOME</th>");
					echo("<th>TELEFONE</th>");
				echo("</tr>");
				while($linhaBd = mysqli_fetch_assoc($ds)){
					$cpf = $linhaBd['cpf'];
					$nome = $linhaBd['nome'];
					$tel = $linhaBd['telefone'];
					echo("<tr>");
						echo("<td>$cpf</td>");
						echo("<td>$nome</td>");
						echo("<td>$tel</td>");
					echo("</tr>");
				}
			echo("</table>");
			echo("$sql");
		}
		/*$ds=mysqli_query($conn,$sql);
		if(!$ds){
			die("Erro na pesquisa na tabela");
		}*/
	?>
</body>
</html>