<?php
	require("conectaBd.php");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style/style.css">
	<title>Pesquisar</title>
</head>
<body>
	<form name="buscar" method="POST" action="result.php">
		<input type="text" name="pesquisa" value="" placeholder="Insira um nome"> <br><br>
		<input type="submit" name="envioDados" value="PESQUISAR"> 
	</form>
</body>
</html>