<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/estilos02.css">
		<link rel="shortcut icon" type="image/jpg" href="images/ale.jpg">	
		<title>Lib-Lab</title>
	</head>
	<body>
			<header class="topnav">
				<li>
					<button class="btnLib">
						<b>Lib-Lab</b>
					</button>
				</li>
				<li class="right">
					<a href="sair.php">
						<button class="btnCadastrar"><b>Cadastro</b></button>
					</a>
				</li>
				<li class="right">
					<a href="login01.php">
						<button class="btnEntrar"><b>Login</b></button>
					</a>
				</li>
			</header>
			<ul>
				<p class="pIndex">APRENDA LIBRAS COM JOGOS!</p>
				<a href="cad01.php">
					<button class="btnComecar"><b>Comece Já</b></button>
				</a>
			</ul>
			<article>
				<div class="ContArt">
					<p class="pAprenda">
						<b>Para que serve o "Lib-Lab"?</b>
					</p>
					<p class="expli">
						Lorem ipsum dolor sit amet, consectetur
						adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore
						magna aliqua. Ut enim ad minim veniam,<br>
						quis nostrud exercitation ullamco
						 laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in 
						reprehenderit in voluptate velit esse<br>
						cillum dolore eu fugiat nulla 
						pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia <br>
						deserunt mollit anim id est laborum.
					</p>
				</div>
				<div class="imgArt">
					
				</div>
			</article>
			<section class="ExpliFunciona">
				<br>
				<div class="txtImg">
					<p class="Como"><b>Como Funciona?</b></p>
					<p>O LibLab funciona através da gamificação, é preciso completar aulas e exercícios, para que novos níveis e objetivos se debloqueiem</p>
				<br>
					<img class="imgFun02" src="images/funciona02.png">
				</div>				
				<div class="imgTxt">
				<br>
				<br>
					<img class="imgFun01" src="images/funciona01.png">
				<br><br><br>
				<br><br><br>
					<p>Os contéudos são apresentados através de imagens,<br> texto, vídeos e gifts animados.</p>
				</div>
			</section>
			<div class="doc">	
				Lorem ipsum dolor, sit amet consectetur adipisicing elit. Magnam tempora maiores 
				porro doloribus iste nobis numquam cupiditate saepe, nihil, aut suscipit, 
				reiciendis voluptate corrupti accusantium sint laborum. Sit, facere vel. Lorem 
				ipsum, dolor sit amet consectetur adipisicing elit. Excepturi distinctio omnis 
				eius aliquid ab tempore laudantium harum eligendi. Itaque error ad exercitationem 
				maxime, provident harum optio animi delectus impedit quibusdam? Lorem ipsum dolor 
				sit amet consectetur adipisicing elit. Maxime, temporibus? Commodi eum delectus 
				dignissimos laboriosam laborum tenetur nostrum corporis nemo unde, recusandae 
				tempore non sed! Voluptatum animi sint perspiciatis iure? Lorem ipsum dolor, sit 
				amet consectetur adipisicing elit. Non icing elit. Excepturi distinctio omnis 
				eius aliquid ab tempore laudantium harum eligendi. Itaque error ad exercitationem 
				maxime, provident harum optio animi delectus impedit quibusdam? Lorem ipsum dolor 
				sit amet consectetur adipisicing elit. Maxime, temporibus? Commodi eum delectus 
				dignissimos laboriosam laborum tenetur nostrmquam cupiditate saepe, nihil, aut 
				suscipit, reiciendis voluptate corrupti accusantium sint laborum. Sit, facere 
				vel. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Excepturi 
				distinctio omnis eius aliquid ab tempore laudantium harum eligendi. Itaque error 
				ad exercitationem maxime, provident harum optio animi dele <br> <br>
				<div class="img" onclick="oi()"><img src="images/logo.png" alt="Logo uniserverZ"></div>
				<br>
				Lorem ipsum dolor, sit amet consectetur adipisicing elit. Magnam tempora maiores 
				porro doloribus iste nobis numquam cupiditate saepe, nihil, aut suscipit, 
				reiciendis voluptate corruptibus tempora quos blanditiis dolorem nostrum 
				reprehenderit quia repudiandae suscipit. Lorem ipsum dolor sit amet consectetur, 
				adipisicing elit. Sed doloribus debitis exercitationem sapiente rerum sequi 
				corporis, id, vitae impedit veritatis quam dolorem est aliquid deserunt assumenda 
				mollitia molestiae! Dicta, enim.
				Lorem ipsum dolor, sit amet consectetur adipisicing elit. Magnam tempora maiores 
				porro doloribus iste nobis numquam cupiditate saepe, nihil, aut suscipit, 
				reiciendis voluptate corrupti accusantium sint laborum. Sit, facere vel. Lorem 
				ipsum, dolor sit amet consectetur adipisicing elit. Excepturi distinctio omnis 
				eius aliquid ab temporror ad exercitationem maxime, provident harum optio animi 
				delectus impedit quibusdam? Lorem ipsum dolor sit amet consectetur adipisicing 
				elit. Maxime, temporibus? Commodi eum delectus dignissimos laboriosam laborum 
				tenetur nostrum corporis nemo unde, recusandae tempore non sed! Voluptatum animi 
				sint perspiciatis iure? Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
				Non reprehenderit saepe assumenda. Enim consequuntur velit harum, error 
				perferendis nihil. Architecto temporibus tempora quos blanditiis dolorem nostrum 
				reprehenderit quia repudiandae suscipit. Lorem ipsum dolor sit amet consectetur, 
				adipisicing elit. Sed doloribus debitis exercitationem sapiente rerum sequi 
				corporis, id, vitae impedit veritatis quam dolorem est aliquid deserunt assumenda 
				mollitia molestiae! Dicta, enim.
			</div>
	</body>

</html>