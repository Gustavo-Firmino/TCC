<?php
	    require("sess_start.php");
	    //require("crip2gr4.php");
     	require("conectaBd.php");

     	/*	vultr.com/docs/using-mysql-blob-data-with-php-on-ubuntu-20-04/
			https://imasters.com.br/back-end/manipulacao-de-dados-blob-com-php-e-mysql
			https://www.mysqltutorial.org/php-mysql-blob/
     	*/
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Imagens do servidor</title>
	</head>
	<body>
		<h1>Imagens do BD</h1>
	<?php
			//$_temp (subir aquivo por upload via form)
			$imagem=file_get_contents("E:\UniServerZ\www\images\chrome.jpg");
			//print($imagem);
			$sql = "select * from imagens";
			$dataset = mysqli_query($conn,$sql);
			if (!$dataset) {
				die("Impossivel recuperar registros!");
			}
			if (mysqli_num_rows($dataset)==0) {
				die("Nenhuma imagem no banco de dados!");
			}
			while ($linhaBd=mysqli_fetch_assoc($dataset)) {
			    $IMG = $linhaBd['imagem'];
			    echo($IMG);
			}
			    	

		?>
	</body>
</html>