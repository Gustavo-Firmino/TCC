<?php
/*
    //(utilizado na situacao 1)$sexo=$_POST['sexo'];
					//situacao 1
					
					echo ("Sexo: $sexo <br>");
					if ($sexo=="0") { 
						die("Você precisa escolher uma opção no campo sexo!");mata o programa para que o dispositivo não execute mais nada
						echo ("Você precisa escolher uma opção no campo sexo!");	
					}
---------------------------------------------------------------------------------
				<!--Situacao de preenchimento de campo 1
				<label for = "sexo">Sexo:</label><br>
				<select name="sexo" id="sexo">
				<option value="0">Escolha: </option>
				<option value="M">Masculino</option>
				<option value="F">Feminino</option>
				<option value="O">Outro</option>
				</select>
				-->
------------------------------------------------------------------------------------

					
*/
?>