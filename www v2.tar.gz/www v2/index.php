<!DOCTYPE html>
<html lan g="pt-br">
	<head>
		<meta charset="utf-8">
		<title>Lib-Lab</title>
		<link rel="stylesheet" type="text/css" href="css-pasta/estilos.css">
		<link rel="icon" type="image/x-icon" href="favicon.ico">
	</head>

	<body>
		<nav>
			<ul class="topnav">
				<li><a class="active" href=""> HOME</a></li>
				<li><a href="fale.php"> Fale conosco!</a></li>
				<li class="right"><a href="log.php">Login</a></li>
				<li class="right"><a href="cad.php">Cadastro</a></li>
			</ul>
		</nav>
		<header> 

			
			<h1><i>Lib-Lab</i></h1>
			<button class="button-iniciar" role="button">
				<a href="cad.php" class="button">Comece Agora!</a>
			</button>
		</header>
	<section>
			<h2>Jogo</h2><br>
			<p>
				aqui terão as informações do jogo 
			</p><br>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum. 
			</p>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</p>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</p>
		</section>
		<footer>
			<p>Todos os direitos estão reservados à ToniniCorporation© </p>
		</footer>
	</body>
</html>