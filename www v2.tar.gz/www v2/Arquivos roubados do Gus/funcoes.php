<?php

function maisUm($entrada = 1){
		return ++$entrada;//realizar o calculo e retorna-lo na mesma funcao
	}

	function menosUm($saida){
		return --$saida;//realizar o calculo e colocar o "return", para retornar a funcao
	}
	function nossoPi(){
		return 3.1415;//nao e necessario a utilizacap de variaveis, ja que PI e um valor fixo, portanto apenas retorna seu valor
	}
	

?>