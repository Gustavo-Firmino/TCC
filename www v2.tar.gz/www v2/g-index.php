<?php 
	require 'sess_start.php';
	$username=$_SESSION['username'];
?>
<!DOCTYPE html>
<html lan g="pt-br">
	<head>
		<meta charset="utf-8">
		<title>Lib-Lab</title>
		<link rel="stylesheet" type="text/css" href="css-pasta/estilos.css">
		<link rel="icon" type="image/x-icon" href="favicon.ico">
	</head>

	<body>
		<nav>
			<ul class="topnav">
				<li class="lib"><b><i>Lib-Lab</i></b></li>
				<li class="right"><a href="sair.php">sair</a></li>
			</ul>
			<?php
				echo "Seja bem vindo, $username ";
			?>
		</nav>
		<div class="modulo">
			<div class="visivel">
				<?php 
					echo "Fase $map <br>";
					echo "<br>";
				?>
			</div>
			<?php
				echo "<button><a href='quests.php'> Começar!</a></button> <br> Nível $Niv "; 
			?>
		</div>

	</body>
</html>